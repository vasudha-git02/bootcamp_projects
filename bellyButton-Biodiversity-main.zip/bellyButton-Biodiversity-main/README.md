# bellyButton-Biodiversity
## Project Overview
Roza is a biological researcher in a prominent  microbiology laboratory. many bacterial species are not well studied and
more remain unknown to science. Roza's role is to discover and document this bacteria. In particular Roza is interested 
in bacterial species that have ability to synthesize proteins that taste like beef. Her lab has partnered with Improbable Beef, a
food startup to research candidate species. Labs across the country had success in synthesizing meat from algae, fungi and micro
organisms found on plant roots. However, Improbable Beef is still searching for the elusive bacteria that will provide the perfect
taste. Roza has the hypothesis that there's a microorganism that provides the next best taste, ans she believes it can be found quite
close to home from bacteria found on the human body. Here's what Roza knows so far. The human body is a source of thousands of types
of bacteria, and different parts of the body harbor different species. Bacteria found in the gut are not the same species that are 
found on a person's eyelashes for example. Furthermore, between individuals the bacterial species may vary even in the same location.
Roza hypothesizes that the ideal bacterial species to make synthetic beef, may be found in the belly button, or atleast in someone's 
belly button. To test her hypothesis, Roza has sampled the navels of people across the country to identofy bacterial species that
colonize our belly buttons. Each person's identity is anonymous. They've instead been assigned an ID number. Now Roza wants to build a 
dashboard that both her and her research participants, and fellow researchers can access. Those who participated in the study will be
able to visit a website and select their ID numbers to see which bacterial species live in their navels. Who knows what they might find.
