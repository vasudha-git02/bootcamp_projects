Score = int(input("Please enter your test score "))
# Determine the grade
if Score>=90:
    print("Your grade is A. Congrats!")
elif Score >=80:
        print("Your grade is B. Nice!")
elif Score >=70:
            print("Your grade is C.Improve!")
elif Score >= 60:
                print("Your grade is D. Work hard!")
else:
                print("Your grade is F. Disaster")