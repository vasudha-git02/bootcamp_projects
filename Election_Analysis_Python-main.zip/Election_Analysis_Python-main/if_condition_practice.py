counties = ["Arapahoe","Denver","Jefferson"]

if counties[3] != 'Jefferson':
    print(counties[2])

