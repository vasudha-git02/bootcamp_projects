

name = "Jacob"
country = "United States"
age = 25
hourly_wage =  80
satisfied = True


print("Hello " + name + "!" )
print("The country is "+country)
print("Age is " + str(age))
print("Hourly wage is "+ str(hourly_wage))
print(f"The daily wage is {hourly_wage*8}")
print(f"Satisfied : {satisfied}")

print (f"Hello I am {name} and I am from {country}. My age is {age}. The daily wage is {hourly_wage*8} and I am {satisfied} ")

