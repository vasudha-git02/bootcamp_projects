counties = ["Arapahoe","Denver","Jefferson"]
if "El paso" in counties or "Arapahoe" in counties:
    print("El paso or Arapahoe is in the counties list")
else:
    print("El paso or Arapohoe is not in the counties list")